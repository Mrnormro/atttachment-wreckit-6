#!/usr/bin/env python3

import os, random
from secret import flag 

W = 32
N = 624
STATE_LEN = N * 4

def u32(x): return x & 0xFFFFFFFF
def rotl32(x, r): r &= 31; return u32((x << r) | (x >> (32 - r)))

A_LCG = 1664525
C_LCG = 1013904223

PHI1   = 0x9E3779B1  
MASK1  = 0xA5A5A5A5
PHI2   = 0x5851F42D  
MASK2  = 0xC3C3C3C3

def xorshift32(x):
    x ^= (x << 13) & 0xFFFFFFFF
    x ^= (x >> 17)
    x ^= (x << 5) & 0xFFFFFFFF
    return x & 0xFFFFFFFF

right_pad = random.randint(0, STATE_LEN - len(flag))
left_pad  = STATE_LEN - len(flag) - right_pad
state_bytes = os.urandom(left_pad) + flag + os.urandom(right_pad)

words = [int.from_bytes(state_bytes[i:i+4], 'big') for i in range(0, STATE_LEN, 4)]

K = int.from_bytes(os.urandom(4), 'big')
M = int.from_bytes(os.urandom(4), 'big')
S = u32(K ^ M ^ 0xDEADBEEF)

# index rotation
r = K % N
words_rot = words[r:] + words[:r]

def rand_odd():
    v = (int.from_bytes(os.urandom(4), 'big') | 1) % N
    return v if v != 0 else 1
A_perm = rand_odd()
B_perm = int.from_bytes(os.urandom(4), 'big') % N
perm = [(A_perm * i + B_perm) % N for i in range(N)]
words_perm = [words_rot[perm[i]] for i in range(N)]

def transform_rounds(x):
    x = u32(x * PHI1)
    x ^= K
    x ^= (x >> 7)
    x ^= ((x << 13) & MASK1)
    x = u32(x * PHI2)
    x ^= M
    x ^= (x >> 9)
    x ^= ((x << 11) & MASK2)
    return u32(x)

T = tuple(transform_rounds(x) for x in words_perm)

R = random.Random()
R.setstate((3, T + (0,), None))
Y1 = [R.getrandbits(32) for _ in range(N)]  
Y2 = []
s = S
for _ in range(N):
    s = u32(A_LCG * s + C_LCG)
    Y2.append(s)

Y3 = []
t = u32(S ^ K)
for _ in range(N):
    t = xorshift32(t)
    Y3.append(u32((t * 0x9E3779B1) ^ 0xBADC0DED))


Z = []
for i in range(N):
    add_term = u32(K * i + M)
    mix = u32(Y1[i] ^ Y2[i] ^ rotl32(Y3[i], (i ^ S) & 31) ^ add_term)
    rsh = ((i * (S & 31)) + (Y2[i] & 31)) & 31
    Z.append(rotl32(mix, rsh))

print(S)
print(u32(K ^ S))
print(u32(M ^ u32(S * PHI1)))
print(u32(A_perm ^ rotl32(S, 7)))
print(u32(B_perm ^ ((S >> 3) | ((S & 7) << 29)))) 

for z in Z:
    print(z)
